import SwiftUI
import WidgetKit


// Add widget view here



struct MeditationWidget_Previews: PreviewProvider {
    static var previews: some View {
        Text("Hello, world!")
        // Replace this with "MeditationWidget()" 
    }
}
