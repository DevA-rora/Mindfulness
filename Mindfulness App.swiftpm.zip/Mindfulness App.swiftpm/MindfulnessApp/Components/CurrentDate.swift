import SwiftUI
import Foundation

struct CurrentDate: View {
    var body: some View {
        VStack {
            Text("Hello World!")
        }
    }
}

struct CurrentDate_Previews: PreviewProvider {
    static var previews: some View {
        CurrentDate()
    }
}
