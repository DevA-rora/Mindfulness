import SwiftUI

// This page redirects to "HomeView"
