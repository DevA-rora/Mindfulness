import SwiftUI

// This page redirects to "JournalView"
