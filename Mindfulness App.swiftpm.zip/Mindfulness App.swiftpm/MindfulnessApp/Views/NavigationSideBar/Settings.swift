import SwiftUI

// This page redirects to "SettingsView"
