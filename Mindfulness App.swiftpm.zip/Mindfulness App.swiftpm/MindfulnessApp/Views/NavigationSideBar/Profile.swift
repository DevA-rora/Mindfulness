import SwiftUI

// This page will redirect to "ProfileView"
