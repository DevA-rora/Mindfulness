import SwiftUI

// This will be the place where my app will have an every day mindfulness pane
// This pane will be a journaling tab where you write down 3 things your grateful for and also some events that have happend recently
// The pane can also be used to journal anything that happens to the user

// Come back to this later
