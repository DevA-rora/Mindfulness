import SwiftUI
// Come back to this later
// Settings Ideas:
/*
 - Play sound on silent (default on)
 - Scale images to fill or fit (scaled to fill on default)
 */

